package com.lunyx.panel;


import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;


public class MainActivity extends Activity {
    private final int bg = Color.rgb(15,19,27), card = Color.rgb(25,31,42), cyan = Color.rgb(102,227,255), muted = Color.rgb(155,169,188);
    private android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle state) { super.onCreate(state); prefs=getSharedPreferences("settings",MODE_PRIVATE); buildUI(); }
    GradientDrawable shape(int color, int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    TextView text(String s, int size, int color, boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    void buildUI(){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root=vertical(); root.setPadding(dp(18),dp(20),dp(18),dp(24)); scroll.addView(root);
        TextView brand=text("LUNYX  /  PANEL",12,cyan,true); root.addView(brand);
        TextView title=text("Control Center",26,Color.WHITE,true); title.setPadding(0,dp(8),0,dp(4)); root.addView(title);
        TextView subtitle=text("Game overlay concept • local settings",13,muted,false); root.addView(subtitle);
        LinearLayout status=vertical(); status.setPadding(dp(14),dp(12),dp(14),dp(12)); status.setBackground(shape(card,dp(14))); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,dp(18),0,dp(12)); root.addView(status,sp);
        status.addView(text("SESSION STATUS",11,muted,true)); TextView statusText=text("Panel ready",18,Color.WHITE,true); statusText.setPadding(0,dp(5),0,0); status.addView(statusText);
        section(root,"VISUAL OPTIONS"); toggle(root,"ESP preview","UI toggle only", "esp",false);
        toggle(root,"Box overlay","Toggle preview", "boxes",true);
        toggle(root,"Skeleton overlay","Toggle preview", "skeleton",false);
        toggle(root,"Distance labels","Toggle preview", "distance",true);
        section(root,"AIM SETTINGS");
        slider(root,"FOV radius", "fov", 1, 180, 90);
        slider(root,"Smoothness", "smooth", 1, 100, 45);
        slider(root,"Aim offset", "offset", 0, 100, 50);
        section(root,"GENERAL"); toggle(root,"Compact mode","Reduce spacing", "compact",false);
        Button reset=new Button(this); reset.setText("RESET SETTINGS"); reset.setTextColor(Color.WHITE); reset.setBackground(shape(Color.rgb(38,47,62),dp(12))); reset.setPadding(0,dp(12),0,dp(12));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48)); rp.setMargins(0,dp(14),0,0); root.addView(reset,rp);
        reset.setOnClickListener(v->{ prefs.edit().clear().apply(); buildUI(); Toast.makeText(this,"Settings reset",Toast.LENGTH_SHORT).show(); });
        setContentView(scroll);
    }
    void section(LinearLayout root,String label){ TextView h=text(label,11,cyan,true); h.setPadding(0,dp(18),0,dp(8)); root.addView(h); }
    void toggle(LinearLayout root,String title,String desc,String key,boolean def){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14),dp(10),dp(10),dp(10)); row.setBackground(shape(card,dp(13)));
        LinearLayout labels=vertical(); labels.addView(text(title,15,Color.WHITE,true)); TextView sub=text(desc,11,muted,false); sub.setPadding(0,dp(3),0,0); labels.addView(sub);
        row.addView(labels,new LinearLayout.LayoutParams(0,-2,1)); Switch sw=new Switch(this); sw.setChecked(prefs.getBoolean(key,def)); sw.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean(key,c).apply()); row.addView(sw);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(4),0,dp(4)); root.addView(row,p);
    }
    void slider(LinearLayout root,String title,String key,int min,int max,int def){
        LinearLayout box=vertical(); box.setPadding(dp(14),dp(10),dp(14),dp(8)); box.setBackground(shape(card,dp(13)));
        TextView label=text(title+"  •  "+prefs.getInt(key,def),14,Color.WHITE,true); box.addView(label);
        SeekBar bar=new SeekBar(this); bar.setMax(max-min); bar.setProgress(prefs.getInt(key,def)-min); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan)); bar.setThumbTintList(android.content.res.ColorStateList.valueOf(cyan)); box.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar b,int value,boolean from){ label.setText(title+"  •  "+(value+min)); if(from)prefs.edit().putInt(key,value+min).apply(); } public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){} });
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(4),0,dp(4)); root.addView(box,p);
    }
    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
