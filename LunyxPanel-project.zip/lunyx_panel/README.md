# Lunyx Panel (Android)

Native Android UI concept panel with persisted toggle and slider settings. It does not implement game tracking, ESP rendering, target selection, or automated aiming.


## Build locally
- Android Studio / Android SDK installed
- JDK 17
- Gradle 8.7+

Open this project in Android Studio and allow Gradle sync. Then choose **Build > Build APK(s)**.

## Build from a phone (GitHub Actions)
1. Upload this folder's contents to a GitHub repository (the `.github/workflows/android.yml` file must be included).
2. In the repository, open **Actions** and choose **Build Android APK**.
3. Tap **Run workflow** and wait for the job to finish successfully.
4. Open the completed workflow run and download the artifact named **LunyxPanel-debug-apk**. Extract the ZIP; inside is the APK to install.

The workflow builds a debug APK. It is not signed for Play Store release.


## Android compatibility
The app's minSdk is 23. It contains no native libraries, so the APK can run on 32-bit and 64-bit Android devices supported by the configured API level.
